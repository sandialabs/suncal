import sys
from PyQt6 import QtWidgets, QtCore, QtGui



table = '''
<h1>Contents</h1>
<table>
<thead>
    <tr>
        <th>Column 1</th><th>Column 2</th><th>Column 3</th>
    </tr>
</thead>
<tbody>
<tr>
    <td>A</td><td>B</td><td>C</td>
</tr>
<tr>
    <td>D</td><td>E</td><td>F</td>
</tr>
</tbody>
</table>
    '''

style = '''table {
    color: blue;
    padding: 20px;
    border-color-top: red;
}'''


app = QtWidgets.QApplication(sys.argv)


print(QtGui.QFontDatabase.families())

class Page(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.widget = QtWidgets.QTextEdit()
        font = self.widget.font()
        font.setPointSize(10)
        self.widget.setFont(font)
        self.widget.setReadOnly(True)
        self.widget.zoomIn(1)
        self.widget.insertHtml(table)

        self.css = QtWidgets.QTextEdit()
        self.css.insertPlainText(style)

        self.button = QtWidgets.QPushButton('Update Style')
        self.button.clicked.connect(self.update)
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.widget)
        layout.addWidget(self.css)
        layout.addWidget(self.button)
        self.setLayout(layout)
        self.update()

    def update(self):
        style = self.css.toPlainText()
        document = self.widget.document()
        document.setDefaultStyleSheet(style)
        document.clear()
        self.widget.insertHtml(table)
#        self.widget.repaint()

page = Page()
page.show()
app.exec()