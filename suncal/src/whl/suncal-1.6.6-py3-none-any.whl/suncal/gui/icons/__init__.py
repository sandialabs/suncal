from .icons import icon, appicon, logo_snl
