''' User interface for Risk Analysis '''
from PyQt6 import QtWidgets, QtCore, QtGui

from ..project import ProjectMPlan
from ..mplan import mplan
from . import gui_styles
from .gui_common import BlockedSignals
from . import widgets


class MPlanWidget(QtWidgets.QWidget):
    ''' Widget for Measurement Assurance Plan '''

    change_help = QtCore.pyqtSignal()  # Tell main window to refresh help display

    def __init__(self, component, parent=None):
        super().__init__(parent)
        assert isinstance(component, ProjectMPlan)
        self.component = component
        layout = QtWidgets.QHBoxLayout()
        self.setLayout(layout)

        self.menu = QtWidgets.QMenu('&MAP')
        self.menu.addSeparator()

    def calculate(self):
        ''' Run calculation. Risk is calculated automatically, so this does nothing. '''

    def get_menu(self):
        ''' Get the menu for this widget '''
        return self.menu

    def update_proj_config(self):
        ''' Save page setup back to project item configuration '''
        # GUI updates model in real time - nothing to do



if __name__ == '__main__':
    import sys
    app = QtWidgets.QApplication(sys.argv)
    main = MPlanWidget(ProjectMPlan())
    main.show()
    app.exec()
