''' Suncal Project Component for Measurement Assurance Plans '''
from dataclasses import asdict

from .component import ProjectComponent
from ..mplan.mplan import MPlan, TestPoint, MPlanOptions


class ProjectMPlan(ProjectComponent):
    ''' Measurement Assurance Plan Project Component '''
    def __init__(self, model: MPlan = None, name: str = 'mplan'):
        super().__init__(name=name)
        if model is None:
            self.model = MPlan()
        else:
            self.model = model
        self._result = self.model

    def calculate(self) -> MPlan:
        ''' Calculate values, returning the model '''
        return self.model

    def get_config(self):
        d = {}
        d['mode'] = 'mplan'
        d['name'] = self.name
        d['desc'] = self.description
        d['options'] = asdict(self.model.options)
        testpoints = [asdict(i) for i in self.model.testpoints]

        # Break equipment into its own list to reduce redundancy
        # And allow same Equipment instance in multiple TestPoints
        # when loading back in.
        equipments = []

        def get_equip_cfg(mconfig):
            ''' Recursively replace "equipment" with "equipment_id"
                while adding the equipment configs to the single
                equipments list.
            '''
            equipment = mconfig.get('equipment')
            if equipment is not None:
                if equipment not in equipments:
                    equipments.append(equipment)
                    mconfig['equipment_id'] = len(equipments)-1
                else:
                    mconfig['equipment_id'] = equipments.index(equipment)
                mconfig.pop('equipment')
            else:  # Indirect measurement
                for measurement in mconfig.get('measurements', []):
                    get_equip_cfg(measurement)

        for testpoint in testpoints:
            measurement = testpoint.get('measurement')
            get_equip_cfg(measurement)

        d['equipments'] = equipments
        d['testpoints'] = testpoints
        return d

    def load_config(self, config):
        ''' Load configuation into the project '''
        self.description = config.get('desc', '')
        self.model.options = MPlanOptions(**config.get('options', {}))
        equipments = config.get('equipments', [])
        for item in config.get('testpoints', []):
            self.model.testpoints.append(TestPoint.fromconfig(item, equipments=equipments))
