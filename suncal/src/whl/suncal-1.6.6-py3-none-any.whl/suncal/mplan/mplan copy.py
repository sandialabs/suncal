''' Measurement Assurance Plan (MAP) '''
from typing import Union, Optional
from dataclasses import dataclass, field
import numpy as np

from ..common import distributions, uparser, unitmgr
from .. import risk
from .report.mplan import MPlanReport


@dataclass
class Distribution:
    ''' A probability distribution '''
    description: str = None
    units: str = None
    name: str = 'norm'
    args: dict[str, float] = field(default_factory=lambda: {'std': 0.5})

    def __post_init__(self):
        unitless_args = {}
        for name, arg in self.args.items():
            if unitmgr.has_units(arg):
                value, self.units = unitmgr.split_units(arg)
                unitless_args[name] = value
            else:
                unitless_args[name] = arg
        self.args = unitless_args
        self.distribution = distributions.get_distribution(self.name, **self.args)

    def get_standard(self):
        ''' Get standard deviation of the distribution '''
        return unitmgr.make_quantity(self.distribution.std(), self.units)


@dataclass
class Tolerance:
    ''' Tolerance Limits '''
    nominal: float = 0.
    plusminus: float = None
    minimum: float = -np.inf
    maximum: float = np.inf

    def __post_init__(self):
        if self.plusminus is not None:
            self.minimum = self.nominal - self.plusminus
            self.maximum = self.nominal + self.plusminus
        else:
            if not np.isfinite(self.minimum) and unitmgr.has_units(self.nominal):
                self.minimum = unitmgr.make_quantity(-np.inf, unitmgr.split_units(self.nominal)[1])
            if not np.isfinite(self.maximum) and unitmgr.has_units(self.nominal):
                self.maximum = unitmgr.make_quantity(np.inf, unitmgr.split_units(self.nominal)[1])

    @property
    def onesided(self):
        ''' Tolerance is single-sided '''
        return self.plusminus is None and (not np.isfinite(self.minimum) or not np.isfinite(self.maximum))

    def issymmetric(self):
        ''' Determine whether the limits are symmetric about the nominal '''
        if not np.isfinite(self.minimum) or not np.isfinite(self.maximum):
            return False
        return np.isclose(self.nominal - self.minimum,
                          self.maximum - self.nominal)



@dataclass
class EquipmentAccuracy:
    ''' The equipment accuracy spec for one function/range '''
    rangemax: float = 100.   # Maximum value measured
    percent_reading: float = 0.
    percent_range: float = 0.
    constant: float = 0.
    constantunits: str = None
    expression: str = None   # Sympifiable expression, function of uncertainty x
    k: float = 2   # Coverage factor of above uncertainties

    def get_accuracy(self, measured: float):
        ''' Get the k=1 accuacy at the measured value '''
        accuracy = measured * self.percent_reading
        accuracy += self.rangemax * self.percent_range
        accuracy += self.constant
        # TODO units
        if self.expression is not None:
            expr, consts = uparser.parse_math_with_quantities(self.expression)
            consts.update({'x': measured})
            accuracy += expr.subs(consts).evalf()
        return accuracy / self.k


@dataclass
class Equipment:
    ''' Specification for one function of one piece of equipment. May
        contain multiple ranges
    '''
    manufacturer: str = None
    model: str = None
    serial: str = None
    function: str = None
    variable: str = None
    ranges: list[EquipmentAccuracy] = field(default_factory=list)
    uncertainties: list[Distribution] = field(default_factory=list)
    description: str = None

    def __post_init__(self):
        if len(self.ranges) > 0 and isinstance(self.ranges[0], dict):
            self.ranges = [EquipmentAccuracy(**r) for r in self.ranges]
        if len(self.uncertainties) > 0 and isinstance(self.uncertainties[0], dict):
            self.uncertainties = [Distribution(**d) for d in self.uncertainties]

    def get_uncertainty(self, measured: float):
        ''' Get the k=2 equipment uncertainty when measuring the nominal
            value
        '''
        # NOTE May need abs value smarts
        rangemaxes = [range.rangemax for range in self.ranges]
        try:
            rangeindex = next(x[0] for x in enumerate(rangemaxes) if x[1] >= measured)  # First range greater
        except StopIteration as exc:
            raise ValueError('Measured value not in equipment ranges') from exc

        # NOTE assumes ranges sorted?
        accuracy = self.ranges[rangeindex].get_accuracy(measured)
        uncertainties = [u.get_standard() for u in self.uncertainties]
        uncertainty = np.sqrt(sum(u**2 for u in uncertainties) + accuracy**2)
        return uncertainty * 2  # k=2


@dataclass
class Measurement:
    ''' A measurement model. May be direct (one equipment/measurement)
        or indirect (an equation applied to multiple equipment/measurements)
    '''
    equation: str = None   # Measurement model/equation
    description: str = None
    equipment: list[Union[dict, Equipment]] = field(default_factory=lambda: [Equipment()])
    # TODO: map equipment to equation variables

    def __post_init__(self):
        if len(self.equipment) > 0 and isinstance(self.equipment[0], dict):
            self.equipment = [Equipment(**eq) for eq in self.equipment]

    def combined_uncertainty(self, nominal: float = 0):
        ''' Get k=2 combined uncertainty at the nominal value '''
        uncerts = [equip.get_uncertainty(nominal) for equip in self.equipment]  # These are k=2 now
        # TODO: goto GUM method here!
        # FOR NOW, LETS RSS THEM
        uncert = np.sqrt(sum(u**2 for u in uncerts))
        return uncert  # k=2

    def measurement_distribution(self, nominal) -> Distribution:
        ''' Get Distribution for measurement uncertainty '''
        uncert = self.combined_uncertainty(nominal)  # TODO: get full distribution shape from MC? Option?
        return Distribution(args={'unc': uncert, 'k': 2})


@dataclass
class SetPoint:
    ''' One setpoint of a measurement (for example, the low and high
        ends of a range could be defined as two setpoints)
    '''
    nominal: float = 0.
    measurement: Union[dict, Measurement] = field(default_factory=Measurement)
    tolerance: Union[dict, Tolerance] = field(default_factory=Tolerance)
    acceptance: Tolerance = None   # This is a manual override of the acceptance limits. Leave None to auto-guardband.
    performance: Tolerance = None  # Optional
    population_itp: float = .8   # Default results in 2% PFA with TUR=4
    population: Distribution = None  # Overrides itp if set

    def __post_init__(self):
        if isinstance(self.measurement, dict):
            self.measurement = Measurement(**self.measurement)
        if isinstance(self.tolerance, dict):
            self.tolerance = Tolerance(**self.tolerance)
        if isinstance(self.acceptance, dict):
            self.acceptance = Tolerance(**self.acceptance)
        if isinstance(self.performance, dict):
            self.performance = Tolerance(**self.performance)
        # TODO: all tolerance/population units should be the same??

    def population_distribution(self) -> Distribution:
        ''' Get distribution representing population '''
        if self.population:
            return self.population

        nominal, units = unitmgr.split_units(self.nominal)
        sigma = 1.
        if not np.isfinite(self.tolerance.minimum) and np.isfinite(self.tolerance.maximum):
            if not np.isclose(self.nominal, self.tolerance.maximum):
                UL = unitmgr.strip_units(unitmgr.convert(self.tolerance.maximum, units))
                sigma = risk.get_sigmaproc_from_itp_arb(
                    Distribution(args={'median': self.nominal, 'std': abs(self.nominal)}).distribution,
                    'std',
                    self.population_itp,
                    LL=-np.inf,
                    UL=UL)
            else:
                nominal = self.tolerance.maximum
                sigma = abs(self.tolerance.maximum)
        elif not np.isfinite(self.tolerance.maximum) and np.isfinite(self.tolerance.minimum):
            if not np.isclose(self.nominal, self.tolerance.minimum):
                LL = unitmgr.strip_units(unitmgr.convert(self.tolerance.minimum, units))
                sigma = risk.get_sigmaproc_from_itp_arb(
                    Distribution(args={'median': self.tolerance.nominal}).distribution,
                    'std',
                    self.population_itp,
                    LL=LL,
                    UL=np.inf)
            else:
                nominal = self.tolerance.minimum
                sigma = abs(self.tolerance.minimum)
        else:
            sigma = risk.get_sigmaproc_from_itp(self.population_itp) * self.tolerance.plusminus
        return Distribution(args={'median': nominal, 'std': sigma})

    def tur(self) -> list[float]:
        ''' Calculate Test Uncertainty Ratio of the measurement at each setpoint '''
        uncert = self.measurement.combined_uncertainty(self.nominal)
        tolerance = (self.tolerance.maximum - self.tolerance.minimum)/2
        tur = tolerance / uncert
        if not np.isfinite(tur):
            tur = np.nan
        # TODO: warn if not symmetric? self.tolerance.tolerance.issymmetric()
        return unitmgr.strip_units(tur)

    def _integration_limits(self, units: 'Unit' = None) -> tuple[float, float, float, float]:
        ''' Get PFA/PFR integration limits, upper/lower tolerance and upper/lower
            acceptance limits.

            Args:
                units: Units for resulting limits

            Returns:
                tol_lower: Lower tolerance limit, converted to `units`
                tol_upper: Upper tolerance limit, converted to `units`
                gb_lower: Lower guardband offset (AL = TL + GBL), converted to `units`
                gb_upper: Upper guardband offset (AU = TU - GBU), converted to `units`
        '''
        tol_lower = unitmgr.strip_units(unitmgr.convert(self.tolerance.minimum, units))
        tol_upper = unitmgr.strip_units(unitmgr.convert(self.tolerance.maximum, units))
        gb_lower = gb_upper = 0
        if self.acceptance is not None:
            accept_lower = unitmgr.strip_units(unitmgr.convert(self.acceptance.minimum, units))
            accept_upper = unitmgr.strip_units(unitmgr.convert(self.acceptance.maximum, units))
            gb_lower = accept_lower - tol_lower
            gb_upper = tol_upper - accept_upper
        return tol_lower, tol_upper, gb_lower, gb_upper

    def pfa(self, apply_guardband=False) -> float:
        ''' Calculate PFA of the measurement at each setpoint '''
        uncert_dist = self.measurement.measurement_distribution(self.nominal)
        pop_distribution = self.population_distribution()
        tol_lower, tol_upper, gb_lower, gb_upper = self._integration_limits(pop_distribution.units)
        if not apply_guardband:
            gb_lower = gb_upper = 0
        pfa = risk.PFA(pop_distribution.distribution, uncert_dist.distribution,
                       tol_lower, tol_upper, gb_lower, gb_upper)
        return pfa

    def pfr(self, apply_guardband=False) -> float:
        ''' Calculate PFR of the measurement at each setpoint '''
        uncert_dist = self.measurement.measurement_distribution(self.nominal)
        pop_distribution = self.population_distribution()
        tol_lower, tol_upper, gb_lower, gb_upper = self._integration_limits(pop_distribution.units)
        if not apply_guardband:
            gb_lower = gb_upper = 0
        pfr = risk.PFR(pop_distribution.distribution, uncert_dist.distribution,
                       tol_lower, tol_upper, gb_lower, gb_upper)
        return pfr

    def cpfa(self, apply_guardband=False) -> float:
        ''' Calculate Conditional PFA of the measurement at the nominal value '''
        uncert_dist = self.measurement.measurement_distribution(self.nominal)
        pop_distribution = self.population_distribution()
        tol_lower, tol_upper, gb_lower, gb_upper = self._integration_limits(pop_distribution.units)
        if not apply_guardband:
            gb_lower = gb_upper = 0
        pfa = risk.PFA_conditional(pop_distribution.distribution, uncert_dist.distribution,
                                   tol_lower, tol_upper, gb_lower, gb_upper)
        return pfa

    def margin(self) -> float:
        ''' Return margin (QMU-K Value) between performance limits and population '''
        if self.performance is None:
            return 0
        population_dist = self.population_distribution()
        distribution = population_dist.distribution
        population_mean = distribution.mean()
        population_std = distribution.std()

        limit_lo = unitmgr.strip_units(unitmgr.convert(self.performance.minimum, population_dist.units))
        limit_hi = unitmgr.strip_units(unitmgr.convert(self.performance.maximum, population_dist.units))
        margin = max((limit_hi - population_mean)/population_std,
                     (population_mean - limit_lo)/population_std)
        return margin

    def _guardband_onesided(self):
        # No population defined, use traditional "U95" guardbanding
        if np.isfinite(self.tolerance.minimum):
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        minimum=self.tolerance.minimum + self.measurement.combined_uncertainty())
        elif np.isfinite(self.tolerance.maximum):
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        maximum=self.tolerance.maximum - self.measurement.combined_uncertainty())
        return self.acceptance


    def _guardband_onesided_modified_tur(self, method: str = 'rss', turlimit: float = 4):
        assert self.population is not None
        pop_nominal = self.population_distribution().distribution.mean()
        if np.isfinite(self.tolerance.minimum):
            tolerance = self.tolerance.minimum
        else:
            tolerance = self.tolerance.maximum

        modified_tur = abs(pop_nominal - tolerance) / self.measurement.combined_uncertainty()
        if modified_tur >= turlimit:
            return None

        gbf = self._guardband_factor(modified_tur, method)
        if np.isfinite(self.tolerance.minimum):
            minimum = pop_nominal - (pop_nominal - self.tolerance.minimum) * gbf
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        minimum=minimum)
        else:
            maximum = pop_nominal + (self.tolerance.maximum - pop_nominal) * gbf
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        maximum=maximum)

        return self.acceptance

    def _guardband_factor(self, tur: float, method: str = 'rss'):
        gbcalc = {'rss': risk.guardband_tur.rss,
                  'rp10': risk.guardband_tur.rp10,
                  'dobbert': risk.guardband_tur.dobbert,
                  'test': risk.guardband_tur.test95}.get(method, risk.guardband_tur.rss)
        return gbcalc(tur)

    def apply_tur_guardband(self, method='rss', turlimit=4) -> Optional[Tolerance]:
        ''' Set Acceptance Limits using TUR guardband method '''
        if self.tolerance.onesided and self.population is None:
            return self._guardband_onesided()  # NOTE: this could be one of the config options too, whether to use modified tur or not
        elif self.tolerance.onesided:
            return self._guardband_onesided_modified_tur(method=method, turlimit=turlimit)

        assert self.tolerance.plusminus is not None  # Only for 2-sided tolerances
        tur = self.tur()
        # Only guardband below the TUR threshold (usually 4)
        if tur >= turlimit:
            return None

        gbf = self._guardband_factor(tur, method)
        self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                    plusminus=self.tolerance.plusminus * gbf)
        return self.acceptance

    def apply_target_guardband(self,
                               target: float = 0.02,
                               conditional: bool = False,
                               allow_negative: bool = False,
                               minimize_pfr: bool = False):
        ''' Set Acceptance Limits using PFA Target guardband method '''
        uncert_dist = self.measurement.measurement_distribution(self.nominal)
        pop_distribution = self.population_distribution()
        unitstr = str(pop_distribution.units)
        tol_lower, tol_upper, _, _ = self._integration_limits(pop_distribution.units)
        if minimize_pfr:
            gbl, gbu = risk.guardband.optimize(
                pop_distribution.distribution, uncert_dist.distribution,
                tol_lower, tol_upper, target=target,
                allow_negative=allow_negative, conditional=conditional)
        else:
            gbofst = risk.guardband.target(
                pop_distribution.distribution, uncert_dist.distribution,
                tol_lower, tol_upper, target_PFA=target)

            if not allow_negative and gbofst < 0:
                gbofst = 0

            gbl = unitmgr.make_quantity(tol_lower, unitstr) + unitmgr.make_quantity(gbofst, unitstr)
            gbu = unitmgr.make_quantity(tol_upper, unitstr) - unitmgr.make_quantity(gbofst, unitstr)

        plusminus = None
        if np.isclose(gbu-self.nominal, self.nominal-gbl):
            plusminus = gbu - self.nominal
        self.acceptance = Tolerance(nominal=self.nominal,
                                    plusminus=plusminus,
                                    minimum=gbl,
                                    maximum=gbu)
        return self.acceptance


@dataclass
class MPlanItem:
    ''' One row in the measurement assurance plan. '''
    quantity: str = None
    description: str = None
    requirement: str = None
    setpoints: list[Union[dict, SetPoint]] = field(default_factory=lambda: [SetPoint()])

    def __post_init__(self):
        if len(self.setpoints) > 0 and isinstance(self.setpoints[0], dict):
            self.setpoints = [SetPoint(**s) for s in self.setpoints]

    def setpoint_values(self):
        ''' Get setpoint value for all setpoints in the measurement '''
        return [q.nominal for q in self.setpoints]

    # TODO: report will check the options and call one of the above guardbanding methods appropriately.

    def fill_tolerances(self):
        ''' Compute setpoint tolerances that can be measured with 4:1 or X% PFA using the
            configured equipment
        '''
        raise NotImplementedError  # TODO



@dataclass
class MPlanOptions:
    maxpfa: float = 0.02
    maxcpfa: float = 0.02
    turlimit: float = 4
    guardband: str = 'rss'
    show_conditional: bool = False
    show_worstspecific: bool = False


class MPlan:
    def __init__(self, name='map'):
        self.name = name
        self.mapitems = []
        self.description = ''
        self.options = MPlanOptions()
        self.report = MPlanReport(self)

    def calculate(self):
        ''' Calculate acceptance limits for each MAP item '''
        for item in self.mapitems:
            for setpoint in item.setpoints:
                if self.options.guardband in ['pfa', 'cpfa']:
                    setpoint.apply_target_guardband(
                        target=self.options.maxpfa,
                        conditional=self.options.show_conditional,  ### Probably shoudl be something else
                        allow_negative=False, ## TODO - Config on map level? or setpoint level?
                        minimize_pfr=False) ## TODO
                else:
                    setpoint.apply_tur_guardband(self.options.guardband,
                                                 turlimit=self.options.turlimit)
        return self  # Model is same as Results
