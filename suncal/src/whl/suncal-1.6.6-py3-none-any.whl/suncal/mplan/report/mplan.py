''' Measurement Assurance Plan Report '''
import numpy as np

from ...common import report


class MPlanReport:
    ''' Generate MAP report '''
    def __init__(self, mplan):
        self.mplan = mplan

    def _format_tolerance(self, tolerance: 'Tolerance'):
        if tolerance.plusminus is not None:
            rptitem = (report.Number(tolerance.nominal), ' ± ', report.Number(tolerance.plusminus))
        elif np.isfinite(tolerance.minimum):
            rptitem = ('≥ ', report.Number(tolerance.minimum))
        elif np.isfinite(tolerance.maximum):
            rptitem = ('≤ ', report.Number(tolerance.maximum))
        else:
            rptitem = 'N/A'
        return rptitem

    def _format_mte(self, equipment: 'Equipment'):
        return ' '.join((equipment.manufacturer, equipment.model))

    def _format_tur(self, tur: float, tolerance: 'Tolerance' = None):
        if not np.isfinite(tur):
            turitem = 'N/A'
        else:
            if tur < self.mplan.options.turlimit:
                turitem = ('<font color="red">', report.Number(tur, n=2), '</font>')
            else:
                turitem = ('<font color="green">', report.Number(tur, n=2), '</font>')

            if tolerance is not None and not tolerance.issymmetric():
                # Asterisk if TUR is not symmetric
                tur = (*turitem, '*')

        return turitem

    def _format_pfa(self, testpoint, conditional=False):
        if conditional:
            pfa = testpoint.cpfa(apply_guardband=True)
        else:
            pfa = testpoint.pfa(apply_guardband=True)
        return report.Number(pfa*100, n=2)

    def _format_acceptance(self, acceptance, tolerance):
        if acceptance is not None:
            acc = self._format_tolerance(acceptance)
            if not acceptance.isclose(tolerance):
                acc = ('<font color="red">', *acc, '</font>')
        else:
            acc = self._format_tolerance(tolerance)
        return acc

    def _format_accuracy(self, rng):
        ''' Format the accuracy of the equipment range '''
        exprparts = []
        if rng.percent_reading:
            exprparts.extend([report.Number(rng.percent_reading*100), '% reading', ' + '])
        if rng.percent_range:
            exprparts.extend([report.Number(rng.percent_range*100), '% range', ' + '])
        if rng.constant:
            exprparts.extend([str(rng.constant), ' + '])
        if rng.expression:
            exprparts.append(str(rng.expression))

        if exprparts[-1] == ' + ':
            exprparts = exprparts[:-1]
        return exprparts

    def summary(self, **kwargs):
        ''' Traditional, condensed MAP table '''
        rpt = report.Report(**kwargs)
        conditional = kwargs.pop('cpfa', False)

        hdr = ['Quantity', 'Value', 'M&TE', 'Uncertainty',
               'Acceptance Limit', 'TUR', 'CPFA %' if conditional else 'PFA %']
        rows = []
        for testpoint in self.mplan.testpoints:
            qty = testpoint.quantity
            tolerance = self._format_tolerance(testpoint.tolerance)
            subrows = []
            if testpoint.measurement.expression:
                # Indirect measurement
                mte = report.Math(testpoint.measurement.expression)

                for meas in testpoint.measurement.measurements:
                    subrows.append([f'⮤ &emsp; ${meas.varname}$',
                                    report.Number(meas.nominal),
                                    '⮤ ' + self._format_mte(meas.equipment),
                                    report.Number(meas.uncertainty()),
                                    '&nbsp;', '&nbsp;', '&nbsp;'])
            else:
                # Direct measurement
                mte = self._format_mte(testpoint.measurement.equipment)

            uncert = report.Number(testpoint.measurement.uncertainty())
            tur = self._format_tur(testpoint.tur(), testpoint.tolerance)
            pfa = self._format_pfa(testpoint, conditional=conditional)
            acceptance = self._format_acceptance(testpoint.acceptance, testpoint.tolerance)

            rows.append([
                qty,
                tolerance,
                mte,
                uncert,
                acceptance,
                tur,
                pfa])
            if subrows:
                rows.extend(subrows)
        rpt.table(rows, hdr)
        return rpt

    def _testpoint_detail_rows(self, testpoint, **kwargs):
        ''' Detail table for one testpoint '''
        conditional = kwargs.pop('cpfa', False)
        emptyrows = ['&nbsp;'] * 4
        rows = []
        rows.append([
            f'**{testpoint.quantity}**',
            self._format_tolerance(testpoint.tolerance),
            report.Number(testpoint.measurement.uncertainty()),
            self._format_acceptance(testpoint.acceptance, testpoint.tolerance),
            self._format_tur(testpoint.tur(), testpoint.tolerance),
            self._format_pfa(testpoint, conditional=conditional)])

        rows.append(['&emsp;Tolerance', self._format_tolerance(testpoint.tolerance)] + emptyrows)
        rows.append(['&emsp;&emsp;Lower Tolerance', report.Number(testpoint.tolerance.minimum)] + emptyrows)
        rows.append(['&emsp;&emsp;Upper Tolerance', report.Number(testpoint.tolerance.maximum)] + emptyrows)
        if testpoint.performance is not None:
            rows.append(['&emsp;&emsp;Lower Performance Limit', report.Number(testpoint.performance.minimum)] + emptyrows)
            rows.append(['&emsp;&emsp;Upper Performance Limit', report.Number(testpoint.performance.maximum)] + emptyrows)
        if testpoint.population is None:
            rows.append(['&emsp;Population In-Tolerance Probability', report.Number(testpoint.population_itp*100, n=2)] + emptyrows)
        else:
            rows.append(['&emsp;Population', '&emsp;'] + emptyrows)
            rows.append(['&emsp;&emsp;Distribution', testpoint.population.name] + emptyrows)
            # TODO Other parameters
        if testpoint.measurement.expression:
            rows.append(['&emsp;Measurement Model', report.Math(testpoint.measurement.expression)] + emptyrows)
            rows.append(['&emsp;Combined Uncertainty', report.Number(testpoint.measurement.uncertainty())] + emptyrows)
            for measurement in testpoint.measurement.measurements:
                equip = measurement.equipment
                rows.append(['&emsp;&emsp;Variable', measurement.varname] + emptyrows)
                rows.append(['&emsp;&emsp;&emsp;Equipment', self._format_mte(equip)] + emptyrows)
                rows.append(['&emsp;&emsp;&emsp;Function', equip.function] + emptyrows)
                rngmin, rngmax = measurement.rangelimits()
                if rngmin > 0:
                    rng = ('(', report.Number(rngmin), report.Number(rngmax), ')')
                else:
                    rng = report.Number(rngmax)
                rows.append(['&emsp;&emsp;&emsp;Range', rng] + emptyrows)

                rows.append(['&emsp;&emsp;&emsp;Accuracy', self._format_accuracy(measurement.equipment_range())] + emptyrows)
                rows.append(['&emsp;&emsp;&emsp;Uncertainty', report.Number(measurement.uncertainty())] + emptyrows)
        else:
            rows.append(['&emsp;Equipment', self._format_mte(testpoint.measurement.equipment)] + emptyrows)
            rows.append(['&emsp;&emsp;Function', testpoint.measurement.equipment.function] + emptyrows)
            rngmin, rngmax = testpoint.measurement.rangelimits()
            if rngmin > 0:
                rng = ('(', report.Number(rngmin), report.Number(rngmax), ')')
            else:
                rng = report.Number(rngmax)
            rows.append(['&emsp;&emsp;Range', rng] + emptyrows)

            rows.append(['&emsp;&emsp;Accuracy', self._format_accuracy(testpoint.measurement.equipment_range())] + emptyrows)
            rows.append(['&emsp;&emsp;Uncertainty', report.Number(testpoint.measurement.uncertainty())] + emptyrows)

        if testpoint.acceptance is not None:
            rows.append(['&emsp;Acceptance Limits', self._format_tolerance(testpoint.acceptance)] + emptyrows)
            rows.append(['&emsp;&emsp;Lower Acceptance', report.Number(testpoint.acceptance.minimum)] + emptyrows)
            rows.append(['&emsp;&emsp;Upper Acceptance', report.Number(testpoint.acceptance.maximum)] + emptyrows)
        else:
            rows.append(['&emsp;Acceptance Limits', self._format_tolerance(testpoint.tolerance)] + emptyrows)
            rows.append(['&emsp;&emsp;Lower Acceptance', report.Number(testpoint.tolerance.minimum)] + emptyrows)
            rows.append(['&emsp;&emsp;Upper Acceptance', report.Number(testpoint.tolerance.maximum)] + emptyrows)

        pfafunc = testpoint.pfa if not conditional else testpoint.cpfa
        rows.append(['&emsp;False Accept', '&emsp;'] + emptyrows)
        rows.append(['&emsp;&emsp;PFA Before Guardband', report.Number(pfafunc(apply_guardband=False))] + emptyrows)
        rows.append(['&emsp;&emsp;PFR Before Guardband', report.Number(testpoint.pfr(apply_guardband=False))] + emptyrows)
        rows.append(['&emsp;&emsp;PFA With Guardband', report.Number(pfafunc(apply_guardband=True))] + emptyrows)
        rows.append(['&emsp;&emsp;PFR With Guardband', report.Number(testpoint.pfr(apply_guardband=True))] + emptyrows)

        if testpoint.performance is not None:
            rows.append(['&emsp;Performance Margin', (report.Number(testpoint.margin()), 'σ')] + emptyrows)
        return rows

    def testpoint_detail(self, itemidx=0, **kwargs):
        ''' Report one testpoint '''
        testpoint = self.mplan.testpoints[itemidx]
        conditional = kwargs.get('cpfa', False)

        rpt = report.Report(**kwargs)
        hdr = ['Quantity', 'Value', 'Uncertainty', 'Acceptance Limit', 'TUR',
               'CPFA %' if conditional else 'PFA %']
        rows = self._testpoint_detail_rows(testpoint, **kwargs)
        rpt.table(rows, hdr)
        return rpt

    def detailed(self, **kwargs):
        ''' Detailed MAP table, all testpoints '''
        rpt = report.Report(**kwargs)
        conditional = kwargs.get('cpfa', False)

        hdr = ['Quantity', 'Value', 'Uncertainty', 'Acceptance Limit', 'TUR',
               'CPFA %' if conditional else 'PFA %']
        rows = []

        for testpoint in self.mplan.testpoints:
            rows.extend(self._testpoint_detail_rows(testpoint, **kwargs))

        rpt.table(rows, hdr)
        return rpt
