''' Measurement Assurance Plan (MAP) '''
from typing import Optional
from dataclasses import dataclass, field
import numpy as np

from ..common import distributions, uparser, unitmgr
from .. import risk
from .. import uncertainty
from .report.mplan import MPlanReport


@dataclass
class Distribution:
    ''' A probability distribution

        Args:
            description: A description of the distribution
            units: Measurement units for all distribution parameters
            name: Name of the distribution (normal, uniform, etc.)
            args: Dictionary of distribution parameters
    '''
    description: str = None
    units: str = None
    name: str = 'norm'
    args: dict[str, float] = field(default_factory=lambda: {'std': 0.5})

    def __post_init__(self):
        unitless_args = {}
        for name, arg in self.args.items():
            if unitmgr.has_units(arg):
                value, self.units = unitmgr.split_units(arg)
                unitless_args[name] = value
            else:
                unitless_args[name] = arg
        self.args = unitless_args
        self.distribution = distributions.get_distribution(self.name, **self.args)

    def get_standard(self):
        ''' Get standard deviation of the distribution with units '''
        return unitmgr.make_quantity(self.distribution.std(), self.units)


@dataclass
class Tolerance:
    ''' Tolerance Limits. If plusminus is supplied, minimum and maximum
        will automatically be computed. Omit plusminus to define
        single-sided tolerance.

        Args:
            nominal: The nominal or expected value
            plusminus: Symmetric plus-or-minus value for the tolerance
            minimum: Lowest allowed value
            maximum: Highest allowed value
    '''
    nominal: float = 0.
    plusminus: float = None
    minimum: float = -np.inf
    maximum: float = np.inf

    def __post_init__(self):
        if self.plusminus is not None:
            self.minimum = self.nominal - self.plusminus
            self.maximum = self.nominal + self.plusminus
        else:
            if not np.isfinite(self.minimum) and unitmgr.has_units(self.nominal):
                self.minimum = unitmgr.make_quantity(-np.inf, unitmgr.split_units(self.nominal)[1])
            if not np.isfinite(self.maximum) and unitmgr.has_units(self.nominal):
                self.maximum = unitmgr.make_quantity(np.inf, unitmgr.split_units(self.nominal)[1])

    @property
    def onesided(self) -> bool:
        ''' Determine if tolerance is single-sided '''
        return self.plusminus is None and (not np.isfinite(self.minimum) or not np.isfinite(self.maximum))

    def issymmetric(self) -> bool:
        ''' Determine if the limits are symmetric about the nominal '''
        if not np.isfinite(self.minimum) or not np.isfinite(self.maximum):
            return False
        return np.isclose(self.nominal - self.minimum,
                          self.maximum - self.nominal)

    def isclose(self, tolerance: 'Tolerance') -> bool:
        ''' Determine if the two tolerances are equal '''
        close = np.isclose(self.nominal, tolerance.nominal, equal_nan=True)
        if self.plusminus is not None and tolerance.plusminus is not None:
            close = close and np.isclose(self.plusminus, tolerance.plusminus)
        else:
            close = close and np.isclose(self.minimum, tolerance.minimum, equal_nan=True)
            close = close and np.isclose(self.maximum, tolerance.maximum, equal_nan=True)
        return close


@dataclass
class EquipmentAccuracy:
    ''' The equipment accuracy spec for one function/range. The various
        components are added to determine the total accuracy at a given
        measured value.

        Args:
            rangemin: Lowest value that can be measured using this function/range
            rangemax: Highest value that can be measured using this function/range
            percent_reading: Accuracy component based on of percent of reading (0-1)
            percent_range: Accuracy component based on percent of rangemax
            constant: Constant component of accuracy
            constantunits: Units for constant parameter
            expression: A formula for computing an additional accuracy component, with
                the measured value denoted 'x' in the expression
            k: Coverage factor of the above uncertainty components
    '''
    rangemin: float = 0.     # Minimum value that can be measured
    rangemax: float = 100.   # Maximum value that can be measured
    percent_reading: float = 0.
    percent_range: float = 0.
    constant: float = 0.
    constantunits: str = None
    expression: str = None   # Sympifiable expression, function of uncertainty x
    k: float = 2   # Coverage factor of above uncertainties

    def get_accuracy(self, measured: float):
        ''' Get the k=1 accuacy at the measured value '''
        if measured < self.rangemin or measured > self.rangemax:
            raise ValueError('Measured value outside equipment range')

        accuracy = measured * self.percent_reading
        accuracy += self.rangemax * self.percent_range
        accuracy += self.constant
        if self.expression is not None:
            expr, consts = uparser.parse_math_with_quantities(self.expression)
            consts.update({'x': measured})
            accuracy += expr.subs(consts).evalf()
        return accuracy / self.k


@dataclass
class Equipment:
    ''' Specification for one function of one piece of equipment. May
        contain multiple ranges.

        Args:
            manufacturer: Equipment manufacturer
            model: Equipment model number
            serial: Equipment serial number
            function: Equipment function used (such as DC Volts)
            ranges: List of EquipmentAccuracy specs for each range
            uncertainties: Additional uncertainty Distributions to apply to
                all ranges (such as repeatability)
            description: Description of the equipment, usage notes, etc.
    '''
    manufacturer: str = None
    model: str = None
    serial: str = None
    function: str = None
    ranges: list[EquipmentAccuracy] = field(default_factory=list)
    uncertainties: list[Distribution] = field(default_factory=list)
    description: str = None

    def get_uncertainty(self, measured: float, rangeid: int = None):
        ''' Get the k=2 equipment uncertainty

            Args:
                measured: Nominal measured value
                rangeid: Index of equipment range used. Leave None to
                    autorange.
        '''
        rng = self.range(measured, rangeid)
        accuracy = rng.get_accuracy(measured)
        uncertainties = [u.get_standard() for u in self.uncertainties]
        uncert = np.sqrt(sum(u**2 for u in uncertainties) + accuracy**2)
        return uncert * 2  # k=2

    def _autorange(self, measured: float):
        ''' Get index of range containing the measured value '''
        # NOTE assumes ranges sorted
        rangelimits = [(rng.rangemin, rng.rangemax) for rng in self.ranges]
        try:
            # Search for first range that encloses measured value
            rangeindex = next(i for i, rng in enumerate(rangelimits) if rng[0] <= measured <= rng[1])
        except StopIteration as exc:
            raise ValueError('Measured value not in equipment ranges') from exc
        return rangeindex

    def rangelimits(self, measured: float, rangeid: int = None):
        '''' Get lower and upper bounds of range containing the measured value

            Args:
                measured: Nominal measured value
                rangeid: Index of equipment range to use. Leave None
                    to autorange.
        '''
        if rangeid is not None:
            rng = self.ranges[rangeid]
        else:
            # Autorange
            rng = self.range(measured)
        return rng.rangemin, rng.rangemax

    def range(self, measured: float, rangeid: int = None):
        ''' Get the EquipemnetAccuracy of the range containing the measured value

            Args:
                measured: Nominal measured value
                rangeid: Index of equipment range to use. Leave None
                    to autorange.
        '''
        if rangeid is None:
            rangeid = self._autorange(measured)
        return self.ranges[rangeid]

    @classmethod
    def fromconfig(cls, config):
        ''' Make an Equipment from configuration dictionary '''
        rangecfg = config.pop('ranges', [])
        ranges = [EquipmentAccuracy(**r) for r in rangecfg]
        unccfg = config.pop('uncertainties', [])
        uncertainties = [Distribution(**d) for d in unccfg]
        return cls(ranges=ranges, uncertainties=uncertainties, **config)


def measurement_factory(config, equipments=None):
    ''' Make Measurement or MeasurementIndirect from the config dictionary '''
    if config.get('expression'):
        return MeasurementIndirect.fromconfig(config, equipments=equipments)
    return Measurement.fromconfig(config, equipments=equipments)


@dataclass
class MeasurementIndirect:
    ''' An indirect measurement model

        Args:
            expression: The measurement model equation
            varname: Variablel to assign this measurement if used in another
                indirect measurement model
            units: Units of result (eg use 'ohm' to convert result from V/A)
            description: Description of the measurement model
            measurements: List of Measurement components used in the model
    '''
    varname: str = 'x'
    expression: str = None
    units: str = None  # Units of result
    description: str = None
    measurements: list['Measurement'] = None   # For Indirect

    @property
    def nominal(self) -> float:
        ''' Get nominal/expected value of the indirect measurement '''
        model = uncertainty.Model(self.expression)
        measurands = {meas.varname: meas.nominal for meas in self.measurements}
        nominal = list(model.eval(measurands).values())[0]
        return unitmgr.convert(nominal, self.units)

    def uncertainty(self) -> float:
        ''' Get k=2 combined uncertainty (GUM) at the nominal value '''
        model = uncertainty.Model(self.expression)
        for measurement in self.measurements:
            v = model.var(measurement.varname).measure(measurement.nominal)
            v.typeb(unc=measurement.uncertainty(), k=2)
        gumresult = model.calculate_gum()
        return gumresult.expand()  # 95%
    # TODO: Get Monte Carlo uncertainty?

    def distribution(self) -> Distribution:
        ''' Get the measurement uncertainty as a Distribution '''
        uncert = self.uncertainty()
        return Distribution(args={'unc': uncert, 'k': 2})

    @classmethod
    def fromconfig(cls, config, equipments=None):
        ''' Create a MeasurementIndirect from the config dictionary '''
        measlist = config.pop('measurements', [])
        measurements = [measurement_factory(m, equipments=equipments) for m in measlist]
        return cls(measurements=measurements, **config)


@dataclass
class Measurement(MeasurementIndirect):
    ''' A direct measurement

        Args:
            varname: Variable name to assign this measurement if used in
                an indirect measurement model
            nominal: Nominal measured value
            equipment: The Equipment used to make the measurement
            description: Description of this meausurement
            force_range: Force the equipment into a specific range
                (index into equipment.ranges)
    '''
    equipment: Equipment = None
    nominal: float = 0
    force_range: int = None

    def uncertainty(self) -> float:
        ''' Get k=2 uncertainty at the nominal value '''
        return self.equipment.get_uncertainty(self.nominal)

    def rangelimits(self):
        ''' Get limits of equipment range used to make the measurement '''
        return self.equipment.rangelimits(self.nominal, self.force_range)

    def equipment_range(self):
        ''' Get equipment range used for the measurement '''
        return self.equipment.range(self.nominal, self.force_range)

    @classmethod
    def fromconfig(cls, config, equipments=None):
        ''' Create a Measurement from the config dictionary '''
        equipid = config.pop('equipment_id')
        if equipments:
            # Reuse same object for equipment
            equipment = equipments[equipid]
        else:
            equipment = Equipment.fromconfig(config.pop('equipment', {}))
        return cls(equipment=equipment, **config)


@dataclass
class TestPoint:
    ''' One test point of a measurement (for example, the low and high
        ends of a range could be defined as two testpoints)

        Args:
            measurement: The Measurement used to verify this testpoint
            tolerance: The tolerance requirement of the testpoint
            acceptance: Acceptance limit of the testpoint. Will be filled in
                using guardband rules when .calculate() is performed on the MPlan.
            performance: The performance limit of the testpoint
            population_itp: In-tolerance probability of the population
                based on historical data
            population: Distribution of historical population data, overrides
                population_itp.
    '''
    quantity: str = None
    description: str = None
    measurement: MeasurementIndirect = field(default_factory=Measurement)
    tolerance: Tolerance = field(default_factory=Tolerance)
    acceptance: Tolerance = None
    performance: Tolerance = None  # Optional
    population_itp: float = .8   # Default results in 2% PFA with TUR=4
    population: Distribution = None  # Overrides itp if set

    @property
    def nominal(self):
        ''' Get nominal value of the testpoint '''
        return self.measurement.nominal

    @classmethod
    def fromconfig(cls, config, equipments=None):
        ''' Create a TestPoint from the configuration dictionary '''
        quantity = config.get('quantity', None)
        description = config.get('description', config.get('desc', None))
        measurement = measurement_factory(config.get('measurement'), equipments=equipments)
        tolerance = Tolerance(**cfg) if (cfg := config.get('tolerance')) else None
        acceptance = Tolerance(**cfg) if (cfg := config.get('acceptance')) else None
        performance = Tolerance(**cfg) if (cfg := config.get('performance')) else None
        population = Distribution(**cfg) if (cfg := config.get('population')) else None
        itp = config.get('population_itp', 0.8)
        return cls(quantity, description, measurement,
                   tolerance, acceptance, performance, itp, population)

    def population_distribution(self) -> Distribution:
        ''' Get the Distribution representing the historical population '''
        if self.population:
            return self.population

        nominal, units = unitmgr.split_units(self.nominal)
        sigma = 1.
        if not np.isfinite(self.tolerance.minimum) and np.isfinite(self.tolerance.maximum):
            if not np.isclose(self.nominal, self.tolerance.maximum):
                UL = unitmgr.strip_units(unitmgr.convert(self.tolerance.maximum, units))
                sigma = risk.get_sigmaproc_from_itp_arb(
                    Distribution(args={'median': self.nominal, 'std': abs(self.nominal)}).distribution,
                    'std',
                    self.population_itp,
                    LL=-np.inf,
                    UL=UL)
            else:
                nominal = self.tolerance.maximum
                sigma = abs(self.tolerance.maximum)
        elif not np.isfinite(self.tolerance.maximum) and np.isfinite(self.tolerance.minimum):
            if not np.isclose(self.nominal, self.tolerance.minimum):
                LL = unitmgr.strip_units(unitmgr.convert(self.tolerance.minimum, units))
                sigma = risk.get_sigmaproc_from_itp_arb(
                    Distribution(args={'median': self.tolerance.nominal}).distribution,
                    'std',
                    self.population_itp,
                    LL=LL,
                    UL=np.inf)
            else:
                nominal = self.tolerance.minimum
                sigma = abs(self.tolerance.minimum)
        else:
            sigma = risk.get_sigmaproc_from_itp(self.population_itp) * self.tolerance.plusminus
        if sigma is None:
            raise ValueError(f'Could not find a population distribution for ITP={self.population_itp*100}%')
        return Distribution(args={'median': nominal, 'std': sigma})

    def tur(self) -> float:
        ''' Calculate Test Uncertainty Ratio of the measurement at each testpoint '''
        uncert = self.measurement.uncertainty()
        tolerance = (self.tolerance.maximum - self.tolerance.minimum)/2
        tur = tolerance / uncert
        if not np.isfinite(tur):
            tur = np.nan
        return unitmgr.strip_units(tur)

    def _integration_limits(self, units=None) -> tuple[float, float, float, float]:
        ''' Get PFA/PFR integration limits, upper/lower tolerance and upper/lower
            acceptance limits.

            Args:
                units: Units for resulting limits

            Returns:
                tol_lower: Lower tolerance limit, converted to `units`
                tol_upper: Upper tolerance limit, converted to `units`
                gb_lower: Lower guardband offset (AL = TL + GBL), converted to `units`
                gb_upper: Upper guardband offset (AU = TU - GBU), converted to `units`
        '''
        tol_lower = unitmgr.strip_units(unitmgr.convert(self.tolerance.minimum, units))
        tol_upper = unitmgr.strip_units(unitmgr.convert(self.tolerance.maximum, units))
        gb_lower = gb_upper = 0
        if self.acceptance is not None:
            accept_lower = unitmgr.strip_units(unitmgr.convert(self.acceptance.minimum, units))
            accept_upper = unitmgr.strip_units(unitmgr.convert(self.acceptance.maximum, units))
            gb_lower = accept_lower - tol_lower
            gb_upper = tol_upper - accept_upper
        if np.isnan(gb_lower):
            gb_lower = 0
        if np.isnan(gb_upper):
            gb_upper = 0
        return tol_lower, tol_upper, gb_lower, gb_upper

    def pfa(self, apply_guardband=False) -> float:
        ''' Calculate PFA of the measurement

            Args:
                apply_guardband: Use guardbanding in PFA calculation
        '''
        uncert_dist = self.measurement.distribution()
        pop_distribution = self.population_distribution()
        tol_lower, tol_upper, gb_lower, gb_upper = self._integration_limits(pop_distribution.units)
        if not apply_guardband:
            gb_lower = gb_upper = 0
        pfa = risk.PFA(pop_distribution.distribution, uncert_dist.distribution,
                       tol_lower, tol_upper, gb_lower, gb_upper)
        return pfa

    def pfr(self, apply_guardband=False) -> float:
        ''' Calculate PFR of the measurement

            Args:
                apply_guardband: Use guardbanding in PFA calculation
        '''
        uncert_dist = self.measurement.distribution()
        pop_distribution = self.population_distribution()
        tol_lower, tol_upper, gb_lower, gb_upper = self._integration_limits(pop_distribution.units)
        if not apply_guardband:
            gb_lower = gb_upper = 0
        pfr = risk.PFR(pop_distribution.distribution, uncert_dist.distribution,
                       tol_lower, tol_upper, gb_lower, gb_upper)
        return pfr

    def cpfa(self, apply_guardband=False) -> float:
        ''' Calculate Conditional PFA of the measurement

            Args:
                apply_guardband: Use guardbanding in PFA calculation
        '''
        uncert_dist = self.measurement.distribution()
        pop_distribution = self.population_distribution()
        tol_lower, tol_upper, gb_lower, gb_upper = self._integration_limits(pop_distribution.units)
        if not apply_guardband:
            gb_lower = gb_upper = 0
        pfa = risk.PFA_conditional(pop_distribution.distribution, uncert_dist.distribution,
                                   tol_lower, tol_upper, gb_lower, gb_upper)
        return pfa

    def margin(self) -> float:
        ''' Return margin (QMU-K Value) between performance limits and population '''
        if self.performance is None:
            return 0
        population_dist = self.population_distribution()
        distribution = population_dist.distribution
        population_mean = distribution.mean()
        population_std = distribution.std()

        limit_lo = unitmgr.strip_units(unitmgr.convert(self.performance.minimum, population_dist.units))
        limit_hi = unitmgr.strip_units(unitmgr.convert(self.performance.maximum, population_dist.units))
        margin = max((limit_hi - population_mean)/population_std,
                     (population_mean - limit_lo)/population_std)
        return margin

    def _guardband_onesided(self):
        ''' Determine acceptance limits for one-sided tolerance using "U95"
            guardband
        '''
        if np.isfinite(self.tolerance.minimum):
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        minimum=self.tolerance.minimum + self.measurement.uncertainty())
        elif np.isfinite(self.tolerance.maximum):
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        maximum=self.tolerance.maximum - self.measurement.uncertainty())
        return self.acceptance

    def _guardband_onesided_modified_tur(self, method: str = 'rss', turlimit: float = 4):
        ''' Use "Modified TUR" to apply guardband to the one-sided tolerance

            Args:
                method: Name of guardbanding method ('rss', 'dobbert', 'rp10', 'test')
                turlimit: TUR below which to apply the guardband
        '''
        assert self.population is not None
        pop_nominal = self.population_distribution().distribution.mean()
        if np.isfinite(self.tolerance.minimum):
            tolerance = self.tolerance.minimum
        else:
            tolerance = self.tolerance.maximum

        modified_tur = abs(pop_nominal - tolerance) / self.measurement.uncertainty()
        if modified_tur >= turlimit:
            return None

        gbf = self._guardband_factor(modified_tur, method)
        if np.isfinite(self.tolerance.minimum):
            minimum = pop_nominal - (pop_nominal - self.tolerance.minimum) * gbf
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        minimum=minimum)
        else:
            maximum = pop_nominal + (self.tolerance.maximum - pop_nominal) * gbf
            self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                        maximum=maximum)

        return self.acceptance

    def _guardband_factor(self, tur: float, method: str = 'rss'):
        ''' Get the guardband factor for the TUR and guardbanding method '''
        gbcalc = {'rss': risk.guardband_tur.rss,
                  'rp10': risk.guardband_tur.rp10,
                  'dobbert': risk.guardband_tur.dobbert,
                  'test': risk.guardband_tur.test95}.get(method, risk.guardband_tur.rss)
        return gbcalc(tur)

    def apply_tur_guardband(self, method='rss', turlimit=4) -> Optional[Tolerance]:
        ''' Set Acceptance Limits using a TUR-based guardband method '''
        if self.tolerance.onesided and self.population is None:
            # NOTE: this could be one of the config options too, whether to use modified tur or not
            return self._guardband_onesided()
        elif self.tolerance.onesided:
            return self._guardband_onesided_modified_tur(method=method, turlimit=turlimit)

        assert self.tolerance.plusminus is not None  # Only for 2-sided tolerances
        tur = self.tur()
        # Only guardband below the TUR threshold (usually 4)
        if tur >= turlimit:
            return None

        gbf = self._guardband_factor(tur, method)
        self.acceptance = Tolerance(nominal=self.tolerance.nominal,
                                    plusminus=self.tolerance.plusminus * gbf)
        return self.acceptance

    def apply_target_guardband(self,
                               target: float = 0.02,
                               conditional: bool = False,
                               allow_negative: bool = False,
                               minimize_pfr: bool = False):
        ''' Set Acceptance Limits using PFA Target guardband method

            Args:
                target: Desired PFA
                conditional: Use Conditional PFA
                allow_negative: Allow negative guardbands (acceptance limits
                    outside the tolerance)
                minimize_pfr: Attempt to minimize the PFR (may result in
                    asymmetric guardbands)
        '''
        uncert_dist = self.measurement.distribution()
        pop_distribution = self.population_distribution()
        unitstr = str(pop_distribution.units)
        tol_lower, tol_upper, _, _ = self._integration_limits(pop_distribution.units)
        if minimize_pfr:
            gbl, gbu = risk.guardband.optimize(
                pop_distribution.distribution, uncert_dist.distribution,
                tol_lower, tol_upper, target=target,
                allow_negative=allow_negative, conditional=conditional)
        else:
            gbofst = risk.guardband.target(
                pop_distribution.distribution, uncert_dist.distribution,
                tol_lower, tol_upper, target_PFA=target)

            if not allow_negative and gbofst < 0:
                gbofst = 0

            gbl = unitmgr.make_quantity(tol_lower, unitstr) + unitmgr.make_quantity(gbofst, unitstr)
            gbu = unitmgr.make_quantity(tol_upper, unitstr) - unitmgr.make_quantity(gbofst, unitstr)

        plusminus = None
        if np.isclose(gbu-self.nominal, self.nominal-gbl):
            plusminus = gbu - self.nominal
        self.acceptance = Tolerance(nominal=self.nominal,
                                    plusminus=plusminus,
                                    minimum=gbl,
                                    maximum=gbu)
        return self.acceptance


@dataclass
class MPlanOptions:
    ''' Measurement Assurance Plan Options

        Args:
            maxpfa: Maximum PFA allowed before guardbanding when
                guardband method is 'pfa' or 'cpfa'
            turlimit: Minimum TUR before guardbanding when using
                a TUR-based guardband method
            guardband: Guardbanding method, `pfa`, `cpfa`, `rss`,
                `dobbert`, `rp10`, `test`.
            cpfa: Show Conditional PFA
            allow_negative_guardband: Allow acceptance limits outside the tolerance
            minimize_pfr: Attempt to minimize PFR when calculating PFA guardbands
    '''
    maxpfa: float = 0.02
    turlimit: float = 4
    guardband: str = 'rss'
    cpfa: bool = False
    allow_negative_guardband = False
    minmimize_pfr = False


class MPlan:
    ''' Measurement Assurance Plan (MAP) '''
    def __init__(self, name='map'):
        self.name = name
        self.testpoints = []
        self.description = ''
        self.options = MPlanOptions()
        self.report = MPlanReport(self)

    def calculate(self):
        ''' Calculate acceptance limits for each MAP item '''
        for testpoint in self.testpoints:
            if self.options.guardband in ['pfa', 'cpfa']:
                testpoint.apply_target_guardband(
                    target=self.options.maxpfa,
                    conditional=self.options.cpfa,
                    allow_negative=self.options.allow_negative_guardband,
                    minimize_pfr=self.options.minmimize_pfr)
            else:
                testpoint.apply_tur_guardband(self.options.guardband,
                                              turlimit=self.options.turlimit)
        return self  # Model is same as Results
