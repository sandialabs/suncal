''' User Interface for Uncertainty Calculator '''

from .gui_main import MainGUI
from ..version import __version__, __date__
